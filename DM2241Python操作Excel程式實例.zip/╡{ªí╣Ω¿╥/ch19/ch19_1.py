# ch19_1.py
import csv

fn = 'csvReport.csv'
with open(fn, encoding='utf-8') as csvFile: # 開啟csv檔案
    csvReader = csv.reader(csvFile)         # 讀檔案建立Reader物件
    listReport = list(csvReader)            # 將資料轉成串列    
print(listReport)                           # 輸出串列



