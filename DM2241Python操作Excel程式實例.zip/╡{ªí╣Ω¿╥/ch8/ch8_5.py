# ch8_5.py
import openpyxl
from openpyxl.styles.numbers import builtin_format_id

print(builtin_format_id('mm:ss'))
print(builtin_format_id('mm-dd-yy'))
print(builtin_format_id('0.00%'))
print(builtin_format_id('0.00'))
print(builtin_format_id('00.00'))
print(builtin_format_id('d-mm-yy'))





