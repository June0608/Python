# ch8_2.py
import openpyxl
from openpyxl.styles.numbers import is_builtin

print(is_builtin('#,##0.00'))
print(is_builtin('0.000'))
print(is_builtin('kkk'))





