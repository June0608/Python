# ch9_1.py
import openpyxl
from openpyxl.utils import FORMULAE

print(type(FORMULAE))
print(len(FORMULAE))
print(FORMULAE)






