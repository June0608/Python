# ch9_2.py
import openpyxl
from openpyxl.utils import FORMULAE

print(f"TODAY : {'TODAY' in FORMULAE}")
print(f"today : {'today' in FORMULAE}")
print(f"SUM   : {'SUM' in FORMULAE}")
print(f"sum   : {'sum' in FORMULAE}")
print(f"TEST  : {'TEST' in FORMULAE}")








