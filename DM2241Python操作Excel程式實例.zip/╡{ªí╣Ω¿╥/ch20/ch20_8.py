# ch20_8.py
import pandas as pd

s = pd.Series([30, 50, 40], index=['Orange', 'Apple', 'Grape'])
print(f"{s.values}")
print(f"{s.index}")



      






















