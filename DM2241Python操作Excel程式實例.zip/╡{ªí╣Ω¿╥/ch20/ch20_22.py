# ch20_22.py
import pandas as pd
data = [{'apple':50,'Orange':30,'Grape':80},{'apple':50,'Grape':80}]
fruits = pd.DataFrame(data)
print(fruits)







