# ch20_23.py
import pandas as pd
cities = {'country':['China','Japan','Singapore'],
          'town':['Beijing','Tokyo','Singapore'],
          'population':[2000, 1600, 600]}
citydf = pd.DataFrame(cities)
print(citydf)









