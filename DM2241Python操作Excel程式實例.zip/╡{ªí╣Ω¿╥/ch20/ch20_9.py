# ch20_9.py
import pandas as pd

s = pd.Series([0, 1, 2, 3, 4, 5])
print(f"s[2:4] = \n{s[2:4]}")
print(f"s[:3] = \n{s[:3]}")
print(f"s[2:] = \n{s[2:]}")
print(f"s[-1:] = \n{s[-1:]}")



      






















