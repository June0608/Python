# ch20_20.py
import pandas as pd

beijing = pd.Series([20, 21, 19], name='Beijing')
print(beijing)







