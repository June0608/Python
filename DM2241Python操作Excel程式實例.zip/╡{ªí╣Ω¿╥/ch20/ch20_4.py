# ch20_4.py
import pandas as pd
import numpy as np

s3 = pd.Series(np.arange(0, 7, 2))
print(f"{s3}")



      






















