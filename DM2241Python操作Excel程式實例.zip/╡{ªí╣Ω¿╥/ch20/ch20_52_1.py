# ch20_52_1.py
import pandas as pd

pd.set_option('display.unicode.east_asian_width', True)
x = pd.read_excel("data20_52.xlsx")
print(x)







