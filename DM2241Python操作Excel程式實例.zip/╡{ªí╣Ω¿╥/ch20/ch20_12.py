# ch20_12.py
import pandas as pd

x = pd.Series([1, 5, 9])
y = pd.Series([2, 4, 8])
print(f"{x > y}")




      






















