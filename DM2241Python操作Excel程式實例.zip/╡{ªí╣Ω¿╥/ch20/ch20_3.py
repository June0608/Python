# ch20_3.py
import pandas as pd

mydict = {'北京':'Beijing', '東京':'Tokyo'}
s2 = pd.Series(mydict)
print(f"{s2}")



      






















