# ch20_11.py
import pandas as pd

x = pd.Series([1, 2])
y = pd.Series([3, 4])
print(f"{x * y}")




      






















