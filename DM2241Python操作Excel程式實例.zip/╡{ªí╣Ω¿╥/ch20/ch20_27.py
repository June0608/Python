# ch20_27.py
import pandas as pd

s1 = pd.Series([1, 2, 3])
s2 = pd.Series([4, 5, 6])
x = s1.add(s2)
print(x)

y = s1.sub(s2)
print(y)












